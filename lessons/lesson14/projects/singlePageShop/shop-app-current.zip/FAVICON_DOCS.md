# 🎨 Favicon Documentation

## 📋 Обзор

В проект добавлены favicon файлы для обеспечения правильного отображения иконки сайта во всех браузерах и устройствах.

## 📁 Созданные файлы

### В папке `public/`:

| Файл | Размер | Назначение |
|------|--------|------------|
| `favicon.ico` | 16x16px | Классический favicon для старых браузеров |
| `favicon.svg` | 32x32px | Современный SVG favicon для новых браузеров |
| `apple-touch-icon.svg` | 180x180px | Иконка для iOS устройств |
| `android-chrome-192x192.svg` | 192x192px | Иконка для Android Chrome |
| `android-chrome-512x512.svg` | 512x512px | Большая иконка для Android |
| `site.webmanifest` | - | Web App Manifest для PWA |

## 🎨 Дизайн иконки

### Концепция:
- **Основа:** Корзина покупок (символ интернет-магазина)
- **Цветовая схема:** 
  - Основной цвет: `#4F46E5` (индиго)
  - Акцентный цвет: `#EF4444` (красный для индикатора)
  - Белый цвет для деталей

### Элементы дизайна:
- 🛒 **Корзина покупок** - основной элемент
- ⭕ **Индикатор количества** - красный кружок с цифрой "3"
- 📦 **Товары в корзине** - белые точки внутри корзины
- 🔍 **Детали** - ручки корзины, разделители

## 🔗 HTML интеграция

Добавлены следующие meta теги в `index.html`:

```html
<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="/favicon.ico">
<link rel="icon" type="image/svg+xml" href="/favicon.svg">
<link rel="apple-touch-icon" href="/apple-touch-icon.svg">
<link rel="icon" type="image/svg+xml" sizes="192x192" href="/android-chrome-192x192.svg">
<link rel="icon" type="image/svg+xml" sizes="512x512" href="/android-chrome-512x512.svg">

<!-- Theme color for mobile browsers -->
<meta name="theme-color" content="#4F46E5">
<meta name="msapplication-TileColor" content="#4F46E5">

<!-- Web App Manifest -->
<link rel="manifest" href="/site.webmanifest">
```

## 📱 Progressive Web App (PWA)

### Web App Manifest (`site.webmanifest`):
- **Название:** "Магазин товаров"
- **Короткое название:** "Shop App"
- **Тема:** Shopping, Business
- **Язык:** Русский
- **Режим отображения:** Standalone
- **Ориентация:** Portrait

### Преимущества PWA:
- ✅ Возможность установки как приложение
- ✅ Работа офлайн (при настройке Service Worker)
- ✅ Нативный внешний вид на мобильных устройствах
- ✅ Иконки для всех платформ

## 🌐 Поддержка браузеров

| Браузер | Поддерживаемые форматы |
|---------|------------------------|
| **Chrome** | ICO, SVG, PNG |
| **Firefox** | ICO, SVG, PNG |
| **Safari** | ICO, SVG, Apple Touch Icon |
| **Edge** | ICO, SVG, PNG |
| **Mobile Chrome** | Android Chrome icons |
| **Mobile Safari** | Apple Touch Icon |

## 🛠 Техническая информация

### Размеры иконок:
- **16x16** - favicon.ico (базовый размер)
- **32x32** - favicon.svg (стандартный)
- **180x180** - Apple Touch Icon
- **192x192** - Android Chrome (стандартный)
- **512x512** - Android Chrome (высокое разрешение)

### Форматы:
- **ICO** - классический формат для максимальной совместимости
- **SVG** - векторный формат для четкости на всех экранах
- **JSON** - веб-манифест для PWA функциональности

## 🔄 Обновление favicon

### Если нужно изменить дизайн:

1. **Отредактировать SVG файлы** в папке `public/`
2. **Пересоздать ICO файл** (при необходимости)
3. **Обновить веб-манифест** при изменении названия/темы
4. **Перезапустить dev сервер** для применения изменений

### Инструменты для создания favicon:
- **Онлайн генераторы:** favicon.io, realfavicongenerator.net
- **Графические редакторы:** Figma, Adobe Illustrator, Inkscape
- **Программные инструменты:** ImageMagick, Sharp (Node.js)

## ✅ Проверка работы

После запуска приложения (`npm start`) проверьте:

1. **В браузере:** иконка должна отображаться во вкладке
2. **В закладках:** иконка должна сохраняться
3. **На мобильных:** при добавлении на домашний экран
4. **DevTools:** проверить загрузку всех файлов в Network tab

### URLs для проверки:
- http://localhost:3000/favicon.ico
- http://localhost:3000/favicon.svg
- http://localhost:3000/site.webmanifest

---

**Автор:** OTUS JavaScript Pro  
**Дата создания:** Октябрь 2025  
**Последнее обновление:** 31.10.2025