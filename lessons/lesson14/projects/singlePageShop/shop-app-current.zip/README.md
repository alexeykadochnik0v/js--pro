# Shop App - Интернет-магазин на React

![React](https://img.shields.io/badge/React-18+-blue.svg)
![TypeScript](https://img.shields.io/badge/TypeScript-5+-blue.svg)
![Redux Toolkit](https://img.shields.io/badge/Redux_Toolkit-1.9+-purple.svg)
![Webpack](https://img.shields.io/badge/Webpack-5+-green.svg)
![Babel](https://img.shields.io/badge/Babel-7+-yellow.svg)

## 📋 Описание проекта

**Shop App** - это современное веб-приложение интернет-магазина, построенное на React с использованием TypeScript. Приложение демонстрирует использование современных технологий фронтенд-разработки и лучших практик архитектуры React-приложений.

### 🎯 Основные возможности

- 📦 **Каталог товаров** - просмотр списка товаров с подробной информацией
- 🛒 **Корзина покупок** - добавление, удаление и изменение количества товаров
- 🔄 **Управление состоянием** - централизованное управление состоянием через Redux Toolkit
- 📱 **Адаптивный дизайн** - оптимизация для различных размеров экранов
- ⚡ **Быстрая загрузка** - оптимизированная сборка с Webpack и Babel

## 🛠 Технологический стек

### Основные технологии:
- **React 18+** - библиотека для создания пользовательских интерфейсов
- **TypeScript 5+** - типизированный JavaScript для более надежного кода
- **Redux Toolkit** - современный способ управления состоянием React приложений
- **CSS Modules** - изолированные стили компонентов

### Инструменты сборки и разработки:
- **Webpack 5** - модульный бандлер
- **Babel 7** - транспилятор JavaScript/TypeScript
- **ESLint** - линтер для проверки качества кода
- **Webpack Dev Server** - сервер разработки с hot reload

### Babel конфигурация:
- `@babel/preset-env` - поддержка современного JavaScript
- `@babel/preset-react` - поддержка JSX
- `@babel/preset-typescript` - поддержка TypeScript
- Автоматические polyfills через `core-js`

## 📁 Структура проекта

```
confRoutes/
├── public/                 # Статические файлы
│   └── index.html         # HTML шаблон
├── src/                   # Исходный код
│   ├── components/        # React компоненты
│   │   ├── Cart.tsx      # Компонент корзины
│   │   ├── CartItem.tsx  # Элемент корзины
│   │   ├── Header.tsx    # Заголовок приложения
│   │   ├── ProductCard.tsx    # Карточка товара
│   │   └── ProductCatalog.tsx # Каталог товаров
│   ├── store/            # Redux store
│   │   ├── index.ts      # Конфигурация store
│   │   ├── cartSlice.ts  # Slice для корзины
│   │   └── productsSlice.ts # Slice для товаров
│   ├── styles/           # CSS модули
│   │   ├── App.module.css
│   │   ├── Cart.module.css
│   │   ├── CartItem.module.css
│   │   ├── Header.module.css
│   │   ├── ProductCard.module.css
│   │   └── ProductCatalog.module.css
│   ├── types/            # TypeScript типы
│   │   └── index.ts      # Общие типы приложения
│   ├── App.tsx           # Главный компонент
│   └── index.tsx         # Точка входа
├── .babelrc              # Конфигурация Babel (JSON)
├── babel.config.js       # Расширенная конфигурация Babel
├── webpack.config.js     # Конфигурация Webpack
├── tsconfig.json         # Конфигурация TypeScript
├── .eslintrc.js          # Конфигурация ESLint
└── package.json          # Зависимости и скрипты
```

## 🚀 Быстрый старт

### Предварительные требования

Убедитесь, что у вас установлены:
- **Node.js** версии 16 или выше
- **npm** версии 8 или выше

### 1. Клонирование репозитория

```bash
git clone <repository-url>
cd confRoutes
```

### 2. Установка зависимостей

```bash
npm install
```

### 3. Запуск в режиме разработки

```bash
npm start
```

Приложение откроется в браузере по адресу: **http://localhost:3000**

### 4. Сборка для продакшена

```bash
npm run build
```

Собранные файлы будут находиться в папке `dist/`

## 📜 Доступные команды

| Команда | Описание |
|---------|----------|
| `npm start` | Запуск сервера разработки на порту 3000 |
| `npm run build` | Сборка приложения для продакшена |
| `npm run lint` | Проверка кода с помощью ESLint |
| `npm run lint:fix` | Автоматическое исправление ошибок ESLint |

## 🏗 Архитектура приложения

### Redux Store
Приложение использует Redux Toolkit для управления состоянием:

- **productsSlice** - управление каталогом товаров (загрузка, кеширование)
- **cartSlice** - управление корзиной покупок (добавление, удаление, подсчет)

### Компоненты
- **App** - корневой компонент с Provider для Redux
- **Header** - навигация и информация о корзине
- **ProductCatalog** - отображение списка товаров
- **ProductCard** - карточка отдельного товара
- **Cart** - компонент корзины покупок
- **CartItem** - элемент корзины

### Стили
Используются CSS Modules для изоляции стилей компонентов.

## 🔧 Конфигурация разработки

### Webpack
- **Dev Server** на порту 3000 с hot reload
- **CSS Modules** для изолированных стилей
- **TypeScript** поддержка через ts-loader и babel-loader
- **Минификация** для продакшен сборки

### Babel
- Поддержка современного JavaScript (ES6+)
- React JSX трансформация
- TypeScript поддержка
- Автоматические polyfills

### ESLint
Настроен для проверки TypeScript и React кода.

## 🐛 Отладка

### Популярные проблемы

1. **Порт 3000 занят**
   ```bash
   # Windows
   netstat -ano | findstr :3000
   taskkill /PID <PID> /F
   ```

2. **Ошибки TypeScript**
   ```bash
   npm run lint
   ```

3. **Очистка кеша**
   ```bash
   rm -rf node_modules dist
   npm install
   ```

## 📚 Полезные ресурсы

- [React Documentation](https://react.dev/)
- [Redux Toolkit](https://redux-toolkit.js.org/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Webpack Documentation](https://webpack.js.org/)
- [Babel Documentation](https://babeljs.io/docs/)

## 📝 Лицензия

Этот проект создан в образовательных целях.

---

**Автор:** DV Senkevich для OTUS JavaScript Pro  
**Дата создания:** Октябрь 2025  
**Версия:** 1.0.0